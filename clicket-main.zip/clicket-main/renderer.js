const {coms} = window;

api.recieve('mouseclick', ()=>{
})
